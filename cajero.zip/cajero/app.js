
let usuario1 = "Mali"
let usuario2 = "Gera"
let usuario3 = "Maui"
let contraseña= 123

//acceso usuario 1
function login(form){
    if (form.usuario.value==usuario1){
        if(form.contraseña.value==contraseña){
            location="cajero1.html";
        }
        else{
            alert("Usuario o Contraseña invalidos, verifique!");
        }
    } else{
        alert("Usuario o Contraseña invalidos, verifique!2");
    }
    if (form.usuario.value==usuario2){
        if(form.contraseña.value==contraseña){
            location="cajero2.html";
        }
        else{
            alert("Usuario o Contraseña invalidos, verifique!");
        }
    } else{
        alert("Usuario o Contraseña invalidos, verifique!2");
    }
    if (form.usuario.value==usuario3){
        if(form.contraseña.value==contraseña){
            location="cajero1.html";
        }
        else{
            alert("Usuario o Contraseña invalidos, verifique!");
        }
    } else{
        alert("Usuario o Contraseña invalidos, verifique!2");
    }
    form.reset();
}

//formulas

function formula1(){
    let total=parseInt(document.getElementById('saldo').value);
    let cantidad1=parseInt(document.getElementById('cantidad').value);
    document.getElementById('saldo').value=(cantidad1+total); 

    if (total>=990){
        alert("No puede tener mas de $990 en su cuenta");
        /*document.getElementById('saldo').value=*/
    }
}


function formula2(){
    let total=parseInt(document.getElementById('saldo').value);
    let cantidad1=parseInt(document.getElementById('cantidad').value);
    document.getElementById('saldo').value=(total-cantidad1);
    alert("Usted retira: " + '$' + cantidad1);
}
function formula3(){
    let total=parseInt(document.getElementById('saldo').value);
    let cantidad1=parseInt(document.getElementById('cantidad').value);
    document.getElementById('NuevoSaldo').value=('$ ' +total);
    alert("Su saldo total es: " +  '$ ' +total);
}


//Como regla de negocio, una cuenta no debe de tener más de $990 
//y menos de $10. Es necesario hacer las validaciones pertinentes 
//para que no se rompa esta regla de negocio
